var TronWeb = require('tronweb');
var BigNumber = require('bignumber.js');
var cron = require('node-cron');
// let polyDistributionAddress = process.argv.slice(2)[0];
let delayTime = 1; //second

var tronWeb;
var contractAddress = 'TGi4QyvLxNnC4J2q98j8EJJRRvAW8BZDvt';
var contract;

async function initTronWeb() {
    tronWeb = new TronWeb({
        // fullNode: 'https://api.trongrid.io', solidityNode: 'https://api.trongrid.io',
        // eventServer: 'https://api.trongrid.io', fullHost: 'https://api.trongrid.io',

        fullNode: 'https://api.shasta.trongrid.io',
        solidityNode: 'https://api.shasta.trongrid.io',
        eventServer: 'https://api.shasta.trongrid.io',
        fullHost: 'https://api.shasta.trongrid.io',

        consume_user_resource_percent: 30,
        fee_limit: 100000000,
        privateKey: 'd3c9322e5493fe9cd012d2a7f552b6c0514d20eec451970e1c0c5850546ea950'
    });

    tronWeb.setDefaultBlock('latest');
    contract = await tronWeb
        .contract()
        .at(contractAddress);
}

function delay(ms) {
    var cur_d = new Date();
    var cur_ticks = cur_d.getTime();
    var ms_passed = 0;
    while (ms_passed < ms) {
        var d = new Date(); // Possible memory leak?
        var ticks = d.getTime();
        ms_passed = ticks - cur_ticks;
        // d = null;  // Prevent memory leak?
    }
}

async function distribute() {
    // while (1) {
    console.log(await contract.test().call());
    delay(delayTime * 1000);

    await contract
        .dailyReward()
        .send({shouldPollResponse: true, callValue: 0});
    // }
}

async function dailyReward() {
    await initTronWeb();
    await distribute();
}

function setCron() {
    cron.schedule('24 20 * * *', async() => {
        await dailyReward();
        console.log("Hello");
    });
    console.log("cronjob started");
}

// dailyReward();
console.log("OKOK");
setCron();
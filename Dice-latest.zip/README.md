## TRON Message Board

[View online demo](https://tronwatch.github.io/TronLink-Demo-Messages/)

This is a simple DApp demo built for TRON. It allows you to post messages,
tip messages and receive tips on your messages. It's powered by [TronWeb](https://github.com/tronprotocol/tron-web)
and integrated using [TronLink](https://github.com/TronWatch/TronLink).

Whilst you do not need TronLink installed to view the site, we recommend installing
it if you want to interact with any messages. You can [install TronLink from the Chrome Webstore](https://chrome.google.com/webstore/detail/ibnejdfjmmkpcnlpebklmnkoeoihofec/).
